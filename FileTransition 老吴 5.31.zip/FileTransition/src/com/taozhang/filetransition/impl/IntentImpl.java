package com.taozhang.filetransition.impl;

import java.net.InetSocketAddress;

public interface IntentImpl {
	
	public void intentToFileActivity(InetSocketAddress address);
	public String getLocalIpAddress(); 
}
