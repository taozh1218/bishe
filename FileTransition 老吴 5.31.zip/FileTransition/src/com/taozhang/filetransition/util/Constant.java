package com.taozhang.filetransition.util;

import android.os.Environment;

public class Constant {
	
	public static int FILE_SELECT_CODE = 50001;
	public static String PROJECTBASE_PATH = Environment.getExternalStorageDirectory()
			+ "/fileTransition";
	public static String DATABASE_PATH = Environment.getExternalStorageDirectory()
			+ "/fileTransition/data";
	public static String DATABASE_FILENAME = "fileTransitionDatabase";
	public static String TABLENAME = "fileinfo";
}
