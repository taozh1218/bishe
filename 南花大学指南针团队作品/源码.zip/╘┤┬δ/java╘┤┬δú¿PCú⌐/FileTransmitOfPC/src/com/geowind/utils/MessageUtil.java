package com.geowind.utils;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class MessageUtil {

	private static final int BUFFERSIZE = 5 * 1024;
	/**
	 * ������Ϣ�ķ���
	 * 
	 * @param msg
	 */
	public static void sendMsg(String msg, DataOutputStream dOps) {
		try {
			dOps.writeUTF(msg);
			dOps.flush();// ǿ�����
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	/**
	 * �ӿͻ��˻�ȡ��Ϣ�ķ���
	 * @param ips
	 * @return client messages
	 * @throws IOException
	 */
	public static String getMsg(DataInputStream dIps) throws IOException {
		String readUTF = dIps.readUTF();
		return readUTF;
	}

	/**
	 * ת16����
	 * 
	 * @param src
	 * @return
	 */
	public static String bytesToHexString(byte[] src) {
		StringBuilder stringBuilder = new StringBuilder();
		if (src == null || src.length <= 0) {
			return null;
		}
		for (int i = 0; i < src.length; i++) {
			int v = src[i] & 0xFF;
			String hv = Integer.toHexString(v);
			if (hv.length() < 2) {
				stringBuilder.append(0);
			}
			stringBuilder.append(hv);
		}
		return stringBuilder.toString();
	}
	
	
	
	/**
	 * ����һ���ļ�
	 */
	public static boolean sendFile(String filePath,DataOutputStream dos){
		
		File file = new File(filePath);
		try {
			FileInputStream fis = new FileInputStream(file);
			String name = file.getName();
			long size = file.length();
			int total = 0;
			dos.writeUTF(name);// �ȷ��ļ���
			dos.writeLong(size);// �ļ���С
			// buffer
			byte[] buffer = new byte[BUFFERSIZE];
			int read = 0;
			while((read = fis.read(buffer,0,buffer.length)) != -1){
				dos.write(buffer, 0, read);
				total += read;
			}
			fis.close();
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	
	public static File getFile(DataInputStream dis){
		File file = null;
		try {
			String name = dis.readUTF();//�ļ���
			long size = dis.readLong();
			int total = 0;
			byte[] buffer = new byte[BUFFERSIZE];
			
//			String type = SplitStringUtil.getTypeBySplit(name);
//			String path = SplitStringUtil.getFilePathByType(type);
			// һ�ɷŵ�����
			file = new File(BaseInfo.DESKTOPPATH,name);
			FileOutputStream fos = new FileOutputStream(file);
			int read = 0;
			while((read = dis.read(buffer,0,BUFFERSIZE)) != -1){
				// д�ļ�
				fos.write(buffer, 0, read);
				total += read;
			}
			fos.close();
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
		return file;
	}
	
}
