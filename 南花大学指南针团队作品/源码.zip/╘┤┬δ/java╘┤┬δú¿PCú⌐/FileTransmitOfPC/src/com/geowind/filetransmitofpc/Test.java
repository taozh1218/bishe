package com.geowind.filetransmitofpc;

import java.awt.AWTException;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Robot;
import java.io.File;
import java.io.IOException;

import com.geowind.utils.ScreenUtils;

public class Test {

	public static void main(String[] args) throws AWTException, InterruptedException, IOException {
		Robot robot = new Robot();
		System.err.println("��ʼ");
		Thread.sleep(500);
	    Dimension screenSize = ScreenUtils.getScreenSize();
		robot.mouseMove(20, 20);
		Thread.sleep(2000);
		String path = "D://JDK";
		File file = new File(path);
		//File[] listFiles = file.listFiles();
		System.err.println("��ʼ���ļ�");
		Thread.sleep(500);
		Desktop.getDesktop().open(file);
		/*for(File f : listFiles){
			if(f.getName().contains("�ļ���Ҫ��¼")){
				Desktop.getDesktop().open(f);
				break;
			}
		}*/
			
		
	}
	
}
