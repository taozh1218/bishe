package com.geowind.thread;

import static org.junit.Assert.fail;

import org.junit.Before;

public class Test {

	@Before
	public void setUp() throws Exception {
	
	}

	@org.junit.Test
	public void test() {
		fail("Not yet implemented");
//		 Assert.assertEquals("5.0",MessageUtil.sendMsg(BaseInfo.OPEND, ops),"0");
	}

}
