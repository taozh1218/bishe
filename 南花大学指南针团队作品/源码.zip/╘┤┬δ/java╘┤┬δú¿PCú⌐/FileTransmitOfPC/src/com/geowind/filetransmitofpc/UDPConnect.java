package com.geowind.filetransmitofpc;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketAddress;
import java.net.SocketException;

public class UDPConnect {
	
private volatile static UDPConnect udpCon ;
private DatagramSocket socket;
	
	private UDPConnect(){
		
	}
	
	
	
	public static UDPConnect getInstance(){
		if(udpCon ==  null){
			synchronized (UDPConnect.class) {
				if(udpCon == null){
					udpCon = new UDPConnect();
				}
			}
		}
		
		return udpCon;
		
	}
	
	
	public void sendMsg(String msg,SocketAddress ip){
		try {
			if(socket == null){
				socket = new DatagramSocket(10088);
			}
			//socket.connect(ip);
			byte[] bytes = msg.getBytes();
			DatagramPacket packet = new DatagramPacket(bytes, bytes.length,ip);
			socket.send(packet);
			socket.close();
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	
	public DatagramPacket getMsg(){
		try {
			if(socket == null){
				socket = new DatagramSocket(10088);
			}
			byte[] bytes = new byte[1024];
			DatagramPacket packet = new DatagramPacket(bytes, bytes.length);
			socket.receive(packet);
			
			socket.close();
			return packet;
		} catch (SocketException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
}
