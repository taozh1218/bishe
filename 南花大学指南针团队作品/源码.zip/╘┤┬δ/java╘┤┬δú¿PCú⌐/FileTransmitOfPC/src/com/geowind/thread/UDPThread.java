package com.geowind.thread;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

import com.geowind.filetransmitofpc.UDPConnect;

public class UDPThread extends Thread {
	private UDPConnect udpCon;
	private String hostName;

	public UDPThread() {
		udpCon = UDPConnect.getInstance();
	}

	@Override
	public void run() {
		try {
			
			hostName = InetAddress.getLocalHost().getHostName();
			DatagramSocket socket = new DatagramSocket(10088);
			while(true){
				System.err.println("�ȴ�UDPЭ����Ϣ");
				// ���ܿͻ��˷�����ip
				byte[] bytes = new byte[1024];
				DatagramPacket pack = new DatagramPacket(bytes, bytes.length);
				socket.receive(pack);
				System.err.println("�ͻ��˷�����ip��: " + new String(pack.getData()));
				// ��ͻ��˷���������
				System.err.println("���ݰ���ip��:  " + pack.getSocketAddress().toString());
				// ��������
				pack.setData(hostName.getBytes());
				socket.send(pack);
				//socket.close();
			}
			

		} catch (SocketException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
