package com.taozhang.filetransition.accesspoint;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;

public class AccessPointManagerTest{

	@Test
	public void testAccessPointManager() {
		fail("Not yet implemented");
		
	}

	

	@Test
	public void testGetWifiApState() {
	}

	@Test
	public void testIsWifiApEnabled() {
		fail("Not yet implemented");
	}

	@Test
	public void testCreateWifiApSSID() {
		fail("Not yet implemented");
	}

	@Test
	public void testStartWifiAp() {
		fail("Not yet implemented");
	}

	@Test
	public void testConnectAP() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetHTCSSID() {
		fail("Not yet implemented");
	}

	@Test
	public void testStopWifiAp() {
		fail("Not yet implemented");
	}

	@Test
	public void testStopWifiApBoolean() {
		fail("Not yet implemented");
	}

	@Test
	public void testDestroy() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetWifiApSSID() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetWiFiHotSpotGate() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetLocalIpAddress() {
		fail("Not yet implemented");
	}

}
