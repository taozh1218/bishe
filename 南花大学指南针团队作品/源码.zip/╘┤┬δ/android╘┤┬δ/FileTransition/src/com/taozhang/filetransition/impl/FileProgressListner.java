package com.taozhang.filetransition.impl;

public interface FileProgressListner {

	public void upDataProgress(float progress);
}
