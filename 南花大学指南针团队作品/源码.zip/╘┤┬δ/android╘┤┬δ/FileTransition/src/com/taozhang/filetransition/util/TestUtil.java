package com.taozhang.filetransition.util;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import android.util.Log;

public class TestUtil {

	public static final String TAG = "tag";
	@Before
	public void setUp() throws Exception {
		
	}

	@Test
	public void testScanMusicFile() {
		fail("Not yet implemented");
		Log.e(TAG, "scanMusicFile");
	}

	@Test
	public void testScanVideoFile() {
		fail("Not yet implemented");
		Log.e(TAG,"scanVideoFile");
		
	}

	@Test
	public void testScanAllFile() {
		fail("Not yet implemented");
		Log.e(TAG, "scanAllFile");
	}

}
